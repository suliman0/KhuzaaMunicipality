package com.example.khuzaamunicipality

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class onboording1 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_onboording1)
    }
}